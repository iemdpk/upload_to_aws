var mysql = require('mysql');

var con = mysql.createConnection({
host: 'localhost', 
port: 3306, 
database: 'Trademaa',
user: 'root', 
password: 'deepak' 
});

const connect = () =>{ 
con.connect(function(err) {
  console.log("Connected!");
});
}

var conChats = mysql.createConnection({
  host: 'localhost', 
  port: 3306, 
  database: 'TrademaaChats',
  user: 'root', 
  password: 'deepak' 
});
  
const connectChats = () =>{ 
    conChats.connect(function(err) {
    console.log("Chats System is Connected Connected!");
  });
}
  
module.exports =  {
  connect,
  con,
  connectChats,
  conChats
};
