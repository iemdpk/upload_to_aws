const express = require('express')
const router = express.Router()
var mysql = require('mysql');
const {connect, con,conChats} = require('../mysqlConnect');

router.get("/sendMessage",(req,res)=>{
  var username = req.query.usernumber;
  var matchRoom = req.query.matchRoom;
  var message = req.query.message;
  console.log("INSERT INTO `"+matchRoom+"` (`id`, `contact_number`, `message`) VALUES ('', '"+username+"', '"+message+"')");
 var resultMain =  conChats.query("INSERT INTO `"+matchRoom+"` (`id`, `contact_number`, `message`) VALUES ('', '"+username+"', '"+message+"')");
 var data = {"status":"ok","msg":"Message is send Added"}
 res.send(data);
});

router.get("/firstTimeChats",(req,res)=>{
try{  
  var usernumber = req.query.usernumber;
  var sellerNumber = req.query.sellerNumber;
  var roomIdName = req.query.roomIdName;
  
  var ChatRoom = usernumber+sellerNumber+Math.floor((Math.random() * 99999999) + 11111111);
  conChats.query("CREATE TABLE `"+ChatRoom+"` (`id` varchar(100) NOT NULL,`contact_number` varchar(100) NOT NULL,`message` varchar(100) NOT NULL);");
  var result =  con.query("INSERT INTO `message` (`id`, `userId`, `sellerId`, `chartRoomSpecialId`, `contact_number`) VALUES (NULL, '"+usernumber+"', '"+sellerNumber+"', '"+ChatRoom+"', '"+roomIdName+"')");
  var data = {"status":"ok","msg":"Message is send Added"}
  res.send(data);
}
catch(err){
  res.send("Table already Exist");
}
  });

router.get("/recieveMessage",(req,res)=>{
  var matchRoom = req.query.matchRoom;

  var data =  conChats.query("Select * from  `"+matchRoom+"`", function (err,result,fields){
    if(err) throw err;
    res.send(result);
  });
  
});

router.get("/showChats",(req,res)=>{
  var number = req.query.number;
  var data =  con.query("SELECT * FROM `message` WHERE `userId`="+number+" OR `sellerId`="+number,function (err,result,fields){
    if(err) throw err;
    res.send(result);
  });
});

module.exports = router