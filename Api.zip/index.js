const express = require('express')
const app = express()
const port = 3001;
const {connect,showTable, con,connectChats} = require('./mysqlConnect');
const axios = require('axios').default;
const server = require('http').createServer(app);
const io = require('socket.io')(server,{cors:{origin:"*"}});

app.use('/api/auth',require('./routes/auth'));
app.use('/api/fetch',require('./routes/showData'));
app.use('/api/chats',require('./routes/chats'));

connect();
connectChats();

io.on("connection", (socket) => {
  console.log(socket.id);
});

app.get('/', (req, res) => {
  res.send('Trademaa Apis');
})

app.get('/check',(req,res)=>{
  
  res.send("This is Check Page")
});

app.get('/fetch', (req, res) => {
  var data = {"name":"deepak","father_Name":"Deepak Mishra"}
  res.send(data);
})

server.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
