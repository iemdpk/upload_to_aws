const express = require('express')
const app = express()
const port = 3001;
const server = require('http').createServer(app);
const io = require('socket.io')(server);
const { connect, showTable, con } = require('./mysqlConnect');
const axios = require('axios').default;



app.use('/api/auth', require('./routes/auth'));
app.use('/api/fetch', require('./routes/showData'));

connect();


app.get('/', (req, res) => {
  res.send('How to work is goin on');
})

app.get('/fetch', (req, res) => {

  var data = { "name": "deepak", "father_Name": "Deepak Mishra" }
  res.send(data);

})
// const CHAT_ROOM=socket.user.name
io.on("connection", (socket) => {
  // join user's own room
	console.log(socket.id);
  // socket.join('room', CHAT_ROOM);

  // console.log("a user connected"); 
  console.log(socket.id + ' ==== connected');
  socket.on("disconnect", () => {
    console.log("user disconnected");
  });

  // Function for room join
  socket.on("join", roomName => {
    console.log("join: " + roomName);
    socket.join(roomName);

  });




  socket.on("message", ({ message, roomName }, callback) => {
    console.log("message: " + message + " in " + roomName);


    // generate data to send to receivers
    const outgoingMessage = {
      name: socket.user.name,
      id: socket.user.id,
      message,
    };
    // // send socket to all in room except sender
    socket.to(roomName).emit("message", outgoingMessage);
    callback({
      status: 'ok'
    });
    // send to all including sender
    // io.to(roomName).emit("message", message);
  });
});


server.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
});


//// Code for create a unique roomName with the two users name 
// io.on('connection', socket => {
//   console.log(socket.id + ' ==== connected');

//   // creating a room name that's unique using both user's unique username

//   socket.on('join', roomName => {
//   let split = roomName.split('--with--'); // ['username2', 'username1']

//   let unique = [...new Set(split)].sort((a, b) => (a < b ? -1 : 1)); // ['username1', 'username2']

//   let updatedRoomName = `${unique[0]}--with--${unique[1]}`; // 'username1--with--username2'

//    Array.from(socket.rooms)
//         .filter(it => it !== socket.id)
//         .forEach(id => {
//           socket.leave(id);
//           socket.removeAllListeners(`emitMessage`);
//         });

//    socket.join(updatedRoomName);

//    socket.on(`emitMessage`, message => {
//       Array.from(socket.rooms)
//            .filter(it => it !== socket.id)
//            .forEach(id => {
//               socket.to(id).emit('onMessage', message);
//            });
//         });
//       });

//     socket.on('disconnect', () => {
//       console.log(socket.id + ' ==== diconnected');
//       socket.removeAllListeners();
//      });
//    });
