const express = require('express')
const router = express.Router()
var mysql = require('mysql');
const {connect, con} = require('../mysqlConnect');

router.get('/registration', (req, res) => {
  var number = req.query.number;
  con.query("INSERT INTO `registration` (`id`, `number`, `confirmet`, `gmail_auth`) VALUES (NULL, '"+number+"', 'no', 'no');",(err,result)=>{
    console.log("Data is Insered");
  });
});

router.get('/sellerRequest', (req, res) => {

  var name = req.query.name;
  var phone = req.query.phone;
  var email = req.query.email;
  var product_img = req.query.product_img;
  var product_title = req.query.product_title;
  var product_desc = req.query.product_desc;
  var product_keywords = req.query.Product_keywords;
  var product_price = req.query.product_price;

  try{
  if(name.length != 0){
    con.query("INSERT INTO `leads` (`id`, `name`, `phone`, `email`, `product_img`, `product_title`, `product_desc`, `Product_keywords`, `product_price`) VALUES (NULL, '"+name+"', '"+phone+"', '"+email+"', '"+product_img+"', '"+product_title+"', '"+product_desc+"', '"+product_keywords+"', '"+product_price+"')",(err,result)=>{
    res.send("Restaurant Created Successfully");
    });
  }
}
catch(err){
  res.send("Please Pass Some Variable Data");
}
});

module.exports = router