const express = require('express')
const router = express.Router()
var mysql = require('mysql');
const {connect, con} = require('../mysqlConnect');
var uuid = require("uuid");

router.get('/registration_Data', (req, res) => {
  var number = req.query.number;
  var special_id = uuid.v4();
  con.query("INSERT INTO `registration` (`id`, `fname`, `lname`, `mobile`, `wallet`, `bank_account`, `special_id`) VALUES (NULL, 'na', 'na', '"+number+"', '0', 'na', '"+special_id+"');",()=>{
    var data = {"status":"ok","msg":"Number Register Successfull"}
    res.send(data);
  });

});

router.get('/registration_extra_data', (req, res) => {
  var special_id = req.query.special_id;
  var name = req.query.name;
  var address = req.query.address;
  var landmark = req.query.landmark;
  con.query("update `owner_registration`  set `name` = '"+name+"',`address`='"+address+"',`landmark`='"+landmark+"' WHERE `special_id` = '"+special_id+"'",(err,result)=>{
    var data = {"status":"ok","msg":"Number Updated Successfull"}
    res.send(data);
  });
});

module.exports = router