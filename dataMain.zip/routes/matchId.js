const express = require('express')
const router = express.Router()
var mysql = require('mysql');
const {connect, con} = require('../mysqlConnect');
var uuid = require("uuid");

router.get('/insertMatchId', (req, res) => {
  
var match_id = req.query.match_id;
var special_id = req.query.special_id;
var gameName = req.query.gameName; 

con.query("INSERT INTO `room_id` (`id`, `special_id`, `game_name`, `match_id`, `allotted`) VALUES (NULL, '"+special_id+"', '"+match_id+"', '"+gameName+"', 'no');",()=>{
    var data = {"status":"ok","msg":"Score updated Successfully"}
    res.send(data);
  });
});

router.get('/insertMatchId', (req, res) => {
  
    var match_id = req.query.match_id;
    var special_id = req.query.special_id;
    var gameName = req.query.gameName; 
    
    con.query("INSERT INTO `room_id` (`id`, `special_id`, `game_name`, `match_id`, `allotted`) VALUES (NULL, '"+special_id+"', '"+match_id+"', '"+gameName+"', 'no');",()=>{
        var data = {"status":"ok","msg":"Score updated Successfully"}
        res.send(data);
      });
    });

    router.get('/showData', (req, res) => {
  
        var match_id = req.query.match_id;
        var special_id = req.query.special_id;
        var gameName = req.query.gameName; 
        
        con.query("INSERT INTO `room_id` (`id`, `special_id`, `game_name`, `match_id`, `allotted`) VALUES (NULL, '"+special_id+"', '"+match_id+"', '"+gameName+"', 'no');",()=>{
            var data = {"status":"ok","msg":"Score updated Successfully"}
            res.send(data);
          });
    });

module.exports = router
