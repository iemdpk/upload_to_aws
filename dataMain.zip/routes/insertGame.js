const express = require('express')
const router = express.Router()
var mysql = require('mysql');
const {connect, con} = require('../mysqlConnect');
var uuid = require("uuid");

router.get('/fruitNinja', (req, res) => {
  
var score = req.query.score;
var special_id = req.query.special_id;
var gameName = req.query.gameName; 
var number = req.query.number; 
var ip = req.query.ip; 
var special_id = req.query.special_id; 

con.query("INSERT INTO `gameScoreBoard` (`id`, `special_id`, `score`, `game`, `number`, `ip_address`, `alloted`) VALUES (NULL, '"+special_id+"', '0', '"+gameName+"', '"+number +"', '"+ip+"', 'no');",()=>{
    var data = {"status":"ok","msg":"Score updated Successfully"}
    res.send(data);
  });
});

module.exports = router
