const express = require('express');
// const { gameOver } = require('../scripts/all');
const app = express()
const port = 3001;
const cors = require('cors');
// const router = express.Router()
const {connect, con} = require('../mysqlConnect');
const axios = require('axios');

app.get('/fruit_ninja_score', cors(), (req, res) => {
            
    axios.get('https://api.ipify.org/?format=json').then((data)=>{
        var scoreNumber = req.query.scoreNumber;
        var ip = data.data.ip;
        var number = req.query.number;
        con.query("UPDATE `gameScoreBoard` set `alloted` = 'yes',`score` = '"+scoreNumber+"' WHERE `ip_address` = '"+ip+"' and `alloted` = 'no';", (err, result) => {
                var data = { "status": "ok", "msg": "Data is Saved" }
                res.send(result);
        });
    });
});

app.get('/fruit_ninja_leader_shop', cors(), (req, res) => {
        con.query("SELECT * FROM `gameScoreBoard` WHERE `alloted` = 'yes' ORDER BY `score`", (err, result) => {
                res.status(200).json(result);
        });
});

app.get('/gamescore_2', cors(), (req, res) => {
    res.send("This is Deepak");
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})
