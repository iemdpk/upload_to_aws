const express = require('express')
const app = express()
const port = 3002;
const {connect,showTable, con} = require('./mysqlConnect');
const axios = require('axios');

app.use('/api/auth',require('./routes/auth'));
app.use('/api/game',require('./routes/insertGame'));
app.use('/api/getRoomId',require('./routes/matchId'));

connect();

app.get('/', (req, res) => {
  res.send('How to work is goin on');
})

app.get('/fetch', (req, res) => {

  var data = {"name":"deepak","father_Name":"Deepak Mishra"}
  res.send(data);
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
